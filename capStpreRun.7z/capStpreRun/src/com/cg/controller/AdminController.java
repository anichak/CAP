package com.cg.controller;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.expression.ParseException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.cg.domain.Category;
import com.cg.domain.Merchant;
import com.cg.domain.Product;
import com.cg.domain.ProductDescription;
import com.cg.service.ServiceClass;
@Controller
@RequestMapping("/")
public class AdminController {

	@Autowired
	public ServiceClass sc;
	@RequestMapping(value="admin_home",method=RequestMethod.POST)
	public String showAdmin(@RequestParam("username")String u , @RequestParam("password")String p){
		if(u.equals("Admin") && p.equals("PASSWORD")){
			return "Admin";
		}else{
			return "Admin_Login";
		}
	}

	@RequestMapping(value="getAllMerchants")
	public String getAllMerchants(ModelMap map) {
		List<Merchant> mList = sc.getAllMerchants();
		map.addAttribute("list",mList);
		return "AllMerchants";
	}

	@RequestMapping(value="getPendingMerchants")
	public String getPendingMerchants(ModelMap map){
		List<Merchant> mList = sc.getPendingMerchants();
		map.addAttribute("list",mList);
		return "Pending";
	}
	
	@RequestMapping(value="getApprovedMerchants")
	public String getApprovedMerchants(ModelMap map){
		List<Merchant> mList = sc.getApprovedMerchants();
		map.addAttribute("list",mList);
		return "Approved";
	}

	@RequestMapping(value="getRemovedOrRejectedMerchants")
	public String getOtherMerchants(ModelMap map){
		map.addAttribute("list",sc.getOtherMerchants());
		return "OtherMerchants";
	}
	
	@RequestMapping(value="approveAMerchant")
	public String approveMerchant(@RequestParam("merchant_id")String id,ModelMap map){
		sc.approveMerchant(id);
		map.addAttribute("list",sc.getPendingMerchants());
		return "Pending";
	}
	
	@RequestMapping(value="rejectAMerchant")
	public String rejectMerchant(@RequestParam("merchant_id")String id,ModelMap map){
		sc.rejectMerchant(id);
		map.addAttribute("list",sc.getPendingMerchants());
		return "Pending";
	}
	
	@RequestMapping(value="removeAMerchant")
	public String removeMerchant(@RequestParam("merchant_id")String id,ModelMap map){
		sc.removeMerchant(id);
		map.addAttribute("list",sc.getApprovedMerchants());
		return "Approved";
	}

	@RequestMapping(value="reapproveAMerchant")
	public String reApproveMerchant(@RequestParam("merchant_id")String id,ModelMap map){
		sc.approveMerchant(id);
		map.addAttribute("list",sc.getOtherMerchants());
		return "OtherMerchants";
	}
	
	@RequestMapping(value="inviteAMerchant")
	public String inviteMerchants(){
		return "InvitationToMerchant";
	}	
	
	@RequestMapping(value="sendInvitationToNewMerchant")
	public String sendInvitation(@RequestParam("sendTo")String toaddress, @RequestParam("subject")String subject, @RequestParam("msgcontent")String content){
		if(sc.emailSender(toaddress, subject, content)){
			return "inviteSuccess";
		}
		else return "inviteFailure";
	}
	
	


	
	
	

}
