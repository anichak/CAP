package com.cg.service;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.cg.domain.Merchant;
import com.cg.repository.IDaoMerchant;

import com.cg.util.Status;

@Service
public class ServiceClass {
	@Value("#{img['ipaddress2']}")	
	String ipaddress;

	@Autowired
	public IDaoMerchant idaomerchant;
	

	final String ALGO = "AES";
	final byte[] keyValue = new byte[] { 'T', 'h', 'e', 'B', 'e', 's', 't','S', 'e', 'c', 'r','e', 't', 'K', 'e', 'y' };	
	
	
	@Transactional
	public boolean activateMerchant(String mer_id,Long ts){
		boolean activated=false;
		Calendar cal=Calendar.getInstance();
		Long ts1=cal.getTimeInMillis();
		Long time=(long) (24*60*60*1000);
		if((ts1-ts)<=time){
			List<Merchant> merchantList=new ArrayList<Merchant>();
			merchantList=idaomerchant.findAll();
			Iterator<Merchant> itr=merchantList.iterator();
			while(itr.hasNext()){
				Merchant merchant=new Merchant();
				merchant=(Merchant)itr.next();
				if(mer_id.equals(merchant.getMerchantId())){
					merchant.setMerchantStatus("Active");
					idaomerchant.saveAndFlush(merchant);
					activated=true;
					break;
				}
			}
		}
		return activated;
	}






	

	@Transactional
	public Merchant getDetailsM(String userid) {
		return idaomerchant.findOne(userid);
	}
	public boolean emailSender(String toaddress, String subject, String content) {
		String host="nsiore01.capgemini.com";
		final String from="Capstore@capgemini.com";
		final String password=" ";

		Properties propertyobj=new Properties();
		propertyobj.put("mail.smtp.starttls.enable", "true");
		propertyobj.put("mail.smtp.host", host);
		propertyobj.put("mail.smtp.user", from);
		propertyobj.put("mail.smtp.password", password);
		propertyobj.put("mail.smtp.port", "25");
		propertyobj.put("mail.smtp.auth", "true");
		propertyobj.put("mail.debug", "true");
		Session session=Session.getDefaultInstance(propertyobj,
				new javax.mail.Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(from,password);
			}
		});
		try	{
			MimeMessage mimemessageobj = new MimeMessage(session);

			mimemessageobj.setFrom(new InternetAddress(from));
			mimemessageobj.setRecipient(Message.RecipientType.TO, new InternetAddress(toaddress));
			mimemessageobj.setSubject(subject);
			mimemessageobj.setText(content);

			Transport transport = session.getTransport("smtp");
			transport.connect(host, from, password);
			mimemessageobj.saveChanges();
			Transport.send(mimemessageobj);
			transport.close();
		}	
		catch(Exception exceptionobj)	{
			System.out.println(exceptionobj);
			return false;
		}
		return true;
	}
	
	@Transactional
	public List<Merchant> getAllMerchants() {
		return idaomerchant.findAll();
	}

	@Transactional
	public List<Merchant> getPendingMerchants() {
		List<Merchant> allMer = idaomerchant.findAll();
		
		Properties pro = Status.getMerchantStatus();
		List<Merchant> pendingMer = new ArrayList<Merchant>();
		for (Merchant m : allMer) {
			if (m.getMerchantStatus().equalsIgnoreCase(pro.getProperty("pending"))) {
				pendingMer.add(m);
			}
		}
		return pendingMer;
	}

	@Transactional
	public List<Merchant> getApprovedMerchants() {
		List<Merchant> allMer = idaomerchant.findAll();
		Properties pro = Status.getMerchantStatus();
		List<Merchant> approvedMer = new ArrayList<Merchant>();
		for (Merchant m : allMer) {
			if (m.getMerchantStatus().equalsIgnoreCase(pro.getProperty("approved"))) {
				approvedMer.add(m);
			}
		}
		return approvedMer;
	}

	@Transactional
	public void approveMerchant(String id) {
		List<Merchant> allMer = idaomerchant.findAll();
		Properties pro = Status.getMerchantStatus();
		Date curr_date = new Date();
		Merchant mtemp = new Merchant();
		for (Merchant m : allMer) {
			if (m.getMerchantId().equalsIgnoreCase(id)) {
				mtemp = m;
				break;
			}
		}
		mtemp.setMerchantStatus(pro.getProperty("approved"));
		mtemp.setMerchantAddeddate(curr_date);
		mtemp.setMerchantRemoveddate(null);
		idaomerchant.save(mtemp);
		//sendEmailToMerchantAboutActivation(mtemp.getMerchantEmail());
	}

	@Transactional
	public void rejectMerchant(String id) {
		List<Merchant> allMer = idaomerchant.findAll();
		Properties pro = Status.getMerchantStatus();
		Date curr_date = new Date();
		Merchant mtemp = new Merchant();
		for (Merchant m : allMer) {
			if (m.getMerchantId().equalsIgnoreCase(id)) {
				mtemp = m;
				break;
			}
		}

		mtemp.setMerchantStatus(pro.getProperty("rejected"));
		mtemp.setMerchantRemoveddate(curr_date);
		idaomerchant.save(mtemp);
	}

	@Transactional
	public void removeMerchant(String id) {
		List<Merchant> allMer = idaomerchant.findAll();
		Properties pro = Status.getMerchantStatus();
		Date curr_date = new Date();
		Merchant mtemp = new Merchant();
		for (Merchant m : allMer) {
			if (m.getMerchantId().equalsIgnoreCase(id)) {
				mtemp = m;
				break;
			}
		}
		mtemp.setMerchantStatus(pro.getProperty("removed"));
		mtemp.setMerchantRemoveddate(curr_date);
		idaomerchant.save(mtemp);
	}

	@Transactional
	public List<Merchant> getOtherMerchants() {
		List<Merchant> allMer = idaomerchant.findAll();
		Properties pro = Status.getMerchantStatus();
		List<Merchant> otherMer = new ArrayList<Merchant>();
		for (Merchant m : allMer) {
			if (m.getMerchantStatus().equalsIgnoreCase(pro.getProperty("removed")) || m.getMerchantStatus().equalsIgnoreCase(pro.getProperty("rejected")) ) {
				otherMer.add(m);
			}
		}
		return otherMer;

	}
	
	
	}
	
	


	
	
	
	
	
	
	
	

