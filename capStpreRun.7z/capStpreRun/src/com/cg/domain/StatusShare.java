package com.cg.domain;

public class StatusShare {
	

}
